var searchData=
[
  ['vardas_0',['vardas',['../class_zmogus.html#a56da52b45c537a31d2c1fc3a53a73c65',1,'Zmogus']]],
  ['vardas_1',['Vardas',['../generavimas_8h.html#a6a3951a03028b1e0317bd46b8ad0c4e1',1,'generavimas.h']]]
];
