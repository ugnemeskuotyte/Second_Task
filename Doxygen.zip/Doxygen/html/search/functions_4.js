var searchData=
[
  ['getegz_0',['getEgz',['../class_studentas.html#a9198f663a0f66b4b1101a0c529b7046d',1,'Studentas']]],
  ['getmark_1',['getMark',['../class_studentas.html#adc3175cbac1b18d694dc0fe8ef1ea5e2',1,'Studentas']]],
  ['getmarks_2',['getMarks',['../class_studentas.html#ab9dc3b5c58a2a83473fdb82ab86f9dbf',1,'Studentas']]],
  ['getname_3',['getName',['../class_studentas.html#ae2d1f25591849507ffbf244f13c55f16',1,'Studentas']]],
  ['getpavarde_4',['getPavarde',['../class_zmogus.html#a11ee9ac120fbb7d6a4e1f4da3a602b63',1,'Zmogus']]],
  ['getresult_5',['getResult',['../class_studentas.html#ab20e25f9fa424fca91cf56841d750596',1,'Studentas']]],
  ['getsurname_6',['getSurname',['../class_studentas.html#a56c0ec75a884bbcde6b37784beb50b3b',1,'Studentas']]],
  ['getvardas_7',['getVardas',['../class_zmogus.html#aaea44664c236e2fadf022f3821862499',1,'Zmogus']]]
];
