var searchData=
[
  ['zmogus_0',['Zmogus',['../class_zmogus.html#aa7a8ba4d3c4778f9b35d59eef3e72574',1,'Zmogus::Zmogus()'],['../class_zmogus.html#a6743dc6ddeaad7c86cc65ebe268d3435',1,'Zmogus::Zmogus(const Zmogus &amp;x)']]]
];
