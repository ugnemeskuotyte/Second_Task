var searchData=
[
  ['clearmarks_0',['clearMarks',['../class_studentas.html#a27fbe0261d9495a28e0043036ec8e863',1,'Studentas']]]
];
