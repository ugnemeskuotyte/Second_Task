var indexSectionsWithContent =
{
  0: "abcdgikmnoprstvz~",
  1: "sz",
  2: "gimrsvz",
  3: "abcdgikmnoprstvz~",
  4: "pv",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends"
};

