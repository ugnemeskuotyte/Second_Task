var searchData=
[
  ['naujas_5ffailas_0',['naujas_failas',['../generavimas_8cpp.html#a8de5e08d663b472826336a4e8905987f',1,'naujas_failas(string failo_pav, int studSk, int ndSk):&#160;generavimas.cpp'],['../generavimas_8h.html#a8de5e08d663b472826336a4e8905987f',1,'naujas_failas(string failo_pav, int studSk, int ndSk):&#160;generavimas.cpp']]],
  ['naujo_5ffailo_5fantraste_1',['naujo_failo_antraste',['../generavimas_8cpp.html#ad9109c1c577fa7f1db95eb90d7802e7d',1,'naujo_failo_antraste(int ndSk):&#160;generavimas.cpp'],['../generavimas_8h.html#ad9109c1c577fa7f1db95eb90d7802e7d',1,'naujo_failo_antraste(int ndSk):&#160;generavimas.cpp']]]
];
