var searchData=
[
  ['tipo_5fpatikra_0',['tipo_patikra',['../validacija_8cpp.html#aba6a05c832d3dbc5cd66550baf964ad5',1,'tipo_patikra():&#160;validacija.cpp'],['../validacija_8h.html#aba6a05c832d3dbc5cd66550baf964ad5',1,'tipo_patikra():&#160;validacija.cpp']]]
];
