var searchData=
[
  ['random_5fpaz_0',['random_paz',['../generavimas_8cpp.html#a6b15611ca46b91089acf31bc28c48ea1',1,'random_paz(int k, Studentas &amp;temp):&#160;generavimas.cpp'],['../generavimas_8h.html#a6b15611ca46b91089acf31bc28c48ea1',1,'random_paz(int k, Studentas &amp;temp):&#160;generavimas.cpp']]]
];
